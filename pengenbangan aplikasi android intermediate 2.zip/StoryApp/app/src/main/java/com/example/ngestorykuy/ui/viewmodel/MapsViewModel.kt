package com.example.ngestorykuy.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asFlow
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.ngestorykuy.data.Result
import com.example.ngestorykuy.data.user.UserRepository
import com.example.ngestorykuy.data.response.StoryResponse
import kotlinx.coroutines.launch

class MapsViewModel(private val repository: UserRepository) :ViewModel() {

    private val _location = MutableLiveData<Result<StoryResponse>>()
    val location: LiveData<Result<StoryResponse>> = _location

    fun getStoriesWithLocation(token: String) {
        viewModelScope.launch {
            repository.getStoriesWithLocation(token).asFlow().collect{
                _location.value = it
            }
        }

    }

    fun getSession() = repository.getSession().asLiveData()
}