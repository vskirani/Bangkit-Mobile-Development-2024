package com.example.ngestorykuy.di

import android.content.Context
import com.example.ngestorykuy.data.user.UserPref
import com.example.ngestorykuy.data.user.UserRepository
import com.example.ngestorykuy.data.user.dataStore

import com.example.ngestorykuy.data.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPref.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return UserRepository.getInstance(apiService, pref)
    }
}