package com.example.ngestorykuy.ui.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ngestorykuy.R
import com.example.ngestorykuy.data.adapter.StoryAdapter
import com.example.ngestorykuy.databinding.ActivityMainBinding
import com.example.ngestorykuy.data.response.Story
import com.example.ngestorykuy.ViewModelFactory
import com.example.ngestorykuy.ui.viewmodel.MainViewModel


class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: StoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                setupAction(user.token)
            }
        }
        setupView()
        supportActionBar?.show()

        adapter = StoryAdapter()
        adapter.notifyDataSetChanged()
        adapter.setOnClickCallback(object : StoryAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Story) {
                Intent(this@MainActivity, DetailActivity::class.java).also {
                    it.putExtra(DetailActivity.NAME, data.name)
                    it.putExtra(DetailActivity.DESC, data.description)
                    it.putExtra(DetailActivity.URL, data.photoUrl)
                    startActivity(it)
                }
            }
        })
        binding.apply {
            rvStory.layoutManager = LinearLayoutManager(this@MainActivity)
            rvStory.setHasFixedSize(true)
            rvStory.adapter = adapter
        }
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.btn_logout -> {
                viewModel.logout()
            }

            R.id.btn_add -> {
                startActivity(Intent(this@MainActivity, AddActivity::class.java))
            }

            R.id.btn_map -> {
                startActivity(Intent(this@MainActivity, MapsActivity::class.java))
            }

        }
        return super.onOptionsItemSelected(item)
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    private fun setupAction(token: String) {
        viewModel.story(token).observe(this) { user ->
            if (user != null) {
                binding.mainProgressBar.visibility = View.GONE
                val adapter = StoryAdapter()
                binding.rvStory.layoutManager = LinearLayoutManager(this)
                adapter.submitData(lifecycle,user)
                binding.rvStory.adapter = adapter
            }
        }
    }


}