package com.example.github_kirani.ui.detail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.github_kirani.data.response.DetailUserResponse
import com.example.github_kirani.ui.ViewModelFactory
import com.example.github_kirani.R
import com.example.github_kirani.data.FavoriteUserEntity
import com.example.github_kirani.databinding.ActivityDetailUserBinding
import com.example.github_kirani.ui.detail.follow.SectionsPagerAdapter
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding

    companion object {
        const val EXTRA_LOGIN = "extra_login"
        const val EXTRA_AVATAR_URL = "extra_avatar_url"
        const val EXTRA_TYPE = "extra_type"
        const val EXTRA_URL = "extra_url"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    private var isFavorite = false
    private var favoriteUser: FavoriteUserEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val detailViewModel: DetailViewModel by viewModels {
            factory
        }


        setSupportActionBar(binding.detailbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = binding.tabLayout.viewPager
        viewPager.adapter = sectionsPagerAdapter

        val tabs: TabLayout = binding.tabLayout.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

        val username = intent.getStringExtra(EXTRA_LOGIN)
        val avatarURl = intent.getStringExtra(EXTRA_AVATAR_URL)
        val type = intent.getStringExtra(EXTRA_TYPE)
        val url = intent.getStringExtra(EXTRA_URL)

        val btnFavorite = binding.btnFav


        detailViewModel.detailUser.observe(this) { detailUser ->
            setDetailUserData(detailUser)
        }


        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        if (username != null) {
            detailViewModel.findDetailUser(username)
        }

        detailViewModel.getFavoriteUserByUsername(username.toString()).observe(this) {
            favoriteUser = it
            isFavorite = if (favoriteUser != null) {
                btnFavorite.setImageDrawable(
                    ContextCompat.getDrawable(
                        btnFavorite.context,
                        R.drawable.fav_red
                    )
                )
                true
            } else {
                btnFavorite.setImageDrawable(
                    ContextCompat.getDrawable(
                        btnFavorite.context,
                        R.drawable.border_fav_red
                    )
                )
                false

            }
        }

        binding.btnFav.setOnClickListener {
            if (isFavorite) {
                detailViewModel.deleteFavoriteUser(favoriteUser as FavoriteUserEntity)
            } else {
                detailViewModel.setFavoriteUser(
                    FavoriteUserEntity(
                        username.toString(),
                        avatarURl.toString(),
                        type.toString(),
                        url.toString()
                    )
                )

            }
        }

        binding.detailbar.setOnMenuItemClickListener {menuItem ->
            when (menuItem.itemId) {
                R.id.action_share -> {
                    val sendIntent: Intent = Intent().apply {
                        action = Intent.ACTION_SEND
                        val content = "${username}, \n${url}"
                        putExtra(Intent.EXTRA_TEXT, content)
                        this.type = "text/plain"
                    }

                    val shareIntent = Intent.createChooser(sendIntent, null)
                    startActivity(shareIntent)
                    true
                }
                else -> false
            }
        }

    }

    private fun setDetailUserData(detailUser: DetailUserResponse) {
        binding.detailNama.text = detailUser.name
        binding.detailUsername.text = detailUser.login
        binding.detailBanyakfollowing.text = detailUser.following.toString()
        binding.detailBanyakfollowers.text = detailUser.followers.toString()
        binding.detailBanyakrepos.text = detailUser.publicRepos.toString()
        binding.detailbar.title = detailUser.name

        Glide.with(this)
            .load(detailUser.avatarUrl)
            .into(binding.detailPropil)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.detailsprogressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_detail, menu)
        return super.onCreateOptionsMenu(menu)
    }
}