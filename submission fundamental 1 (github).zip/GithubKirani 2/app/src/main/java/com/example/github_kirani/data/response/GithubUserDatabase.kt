package com.example.github_kirani.data.response

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.github_kirani.data.FavoriteUserEntity

@Database(
    entities = [FavoriteUserEntity::class],
    version = 1,
    exportSchema = true
)
abstract class GithubUserDatabase : RoomDatabase() {
    abstract fun githubUserDao(): GithubUserDao


    companion object {
        @Volatile
        private var instance: GithubUserDatabase? = null
        fun getInstance(context: Context): GithubUserDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    GithubUserDatabase::class.java, "Github.db"
                )
                    .build()
            }
    }
}