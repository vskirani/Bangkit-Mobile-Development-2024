package com.example.github_kirani.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.addCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.github_kirani.R
import com.example.github_kirani.data.response.ItemsItem
import com.example.github_kirani.ui.favorite.FavoriteActivity
import com.example.github_kirani.ui.detail.SettingActivity
import com.example.github_kirani.databinding.ActivityMainBinding
import com.google.android.material.search.SearchView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var onBackPressedCallback: OnBackPressedCallback

    companion object {
        private var USER_LOGIN = "user_login"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inisialisasi onBackPressedCallback sebelum penggunaan
        onBackPressedCallback = this@MainActivity.onBackPressedDispatcher.addCallback(this@MainActivity, false) {
            binding.searchViewmain.hide()
        }

        val layoutManager = LinearLayoutManager(this)
        binding.itemListUser.rvListUser.layoutManager = layoutManager

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val mainViewModel: MainViewModel by viewModels {
            factory
        }

        mainViewModel.getThemeSetting().observe(this) { isDarkModeActive: Boolean ->
            setTheme(isDarkModeActive)
        }

        mainViewModel.listUser.observe(this) { listUser ->
            setListUser(listUser)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        mainViewModel.isFound.observe(this) {
            showDataIsFound(it)
        }

        with(binding) {
            searchViewmain.apply {
                searchViewmain.setupWithSearchBar(searchBarmain)
                addTransitionListener { _, _, newState ->
                    if (newState == SearchView.TransitionState.SHOWN || newState == SearchView.TransitionState.SHOWING) {
                        searchViewmain.visibility = View.VISIBLE
                    } else {
                        searchViewmain.visibility = View.GONE
                    }
                    onBackPressedCallback.isEnabled = newState == SearchView.TransitionState.SHOWN || newState == SearchView.TransitionState.SHOWING
                }

                editText.setOnEditorActionListener { _, _, _ ->
                    searchBarmain.text = searchViewmain.text
                    USER_LOGIN = searchViewmain.text.toString()
                    searchViewmain.hide()
                    mainViewModel.findUser(USER_LOGIN)
                    false
                }
            }
        }

        binding.toolbarmain.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu1 -> {
                    val intent = Intent(this@MainActivity, FavoriteActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.menu2 -> {
                    val intent = Intent(this@MainActivity, SettingActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }


    private fun setListUser(user: List<ItemsItem>) {
        val adapter = ListUserAdapter()
        adapter.submitList(user)
        binding.itemListUser.rvListUser.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.itemListUser.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showDataIsFound(isFound: Boolean) {
        if (isFound) {
            binding.itemListUser.ilistNotFound.visibility = View.VISIBLE
            binding.itemListUser.dataNotfound.visibility = View.VISIBLE
            binding.itemListUser.fotoTidakditemukan.visibility = View.VISIBLE
            binding.itemListUser.fotoTidakditemukan.visibility = View.INVISIBLE
        } else {
            binding.itemListUser.ilistNotFound.visibility = View.INVISIBLE
            binding.itemListUser.dataNotfound.visibility = View.INVISIBLE
            binding.itemListUser.fotoTidakditemukan.visibility = View.INVISIBLE
            binding.itemListUser.ilistSearch.visibility = View.INVISIBLE
        }
    }

    private fun setTheme(isDarkModeActive: Boolean) {
        if (isDarkModeActive) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
}