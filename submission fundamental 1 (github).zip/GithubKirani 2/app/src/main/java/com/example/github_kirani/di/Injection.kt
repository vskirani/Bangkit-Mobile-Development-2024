package com.example.github_kirani.di

import android.content.Context
import com.example.github_kirani.data.GithubUserRepository
import com.example.github_kirani.data.SettingPreferences
import com.example.github_kirani.data.dataStore
import com.example.github_kirani.data.response.GithubUserDatabase
import com.example.github_kirani.ui.AppExecutors
import com.example.github_kirani.data.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): GithubUserRepository {
        val apiService = ApiConfig.getApiService()
        val database = GithubUserDatabase.getInstance(context)
        val dao = database.githubUserDao()
        val appExecutors = AppExecutors()
        val settingPreference = SettingPreferences.getInstance(context.dataStore)
        return GithubUserRepository.getInstance(apiService, dao, appExecutors, settingPreference)
    }
}