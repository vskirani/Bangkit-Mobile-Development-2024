package com.example.githubuser_kirani.data.response

data class User(
    val login: String,
    val id: Int,
    val  avatar_url: String
)
