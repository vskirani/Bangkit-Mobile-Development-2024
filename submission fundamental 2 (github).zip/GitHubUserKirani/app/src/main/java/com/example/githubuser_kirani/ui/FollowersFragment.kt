package com.example.githubuser_kirani.ui


import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser_kirani.R
import com.example.githubuser_kirani.databinding.FragmentFollowersBinding

class FollowersFragment : Fragment(R.layout.fragment_followers) {
    private var _binding : FragmentFollowersBinding? = null
    private val binding get () = _binding!!
    private lateinit var  viewModel: FollowersViewModel
    private lateinit var adapter: UserAdapter
    private lateinit var userm : String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentFollowersBinding.bind(view)
        super.onViewCreated(view, savedInstanceState)

        val arg = arguments
        userm = arg?.getString(DetailUserActivity.EXTRA_USERNAME).toString()

        adapter = UserAdapter()
        adapter.notifyDataSetChanged()

        binding.apply {
            rvFolower.setHasFixedSize(true)
            rvFolower.layoutManager = LinearLayoutManager(activity)
            rvFolower.adapter = adapter
        }
        showLoading(true)
        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowersViewModel::class.java)
        viewModel.setListFollowers(userm)
        viewModel.getListFollowers().observe(viewLifecycleOwner) {
            if (it != null) {
                adapter.setList(it)
                showLoading(false)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding =null
    }

    private fun showLoading(a: Boolean){
        if(a){
            binding.barProgresFolower.visibility = View.VISIBLE
        }else{
            binding.barProgresFolower.visibility = View.GONE
        }
    }




}