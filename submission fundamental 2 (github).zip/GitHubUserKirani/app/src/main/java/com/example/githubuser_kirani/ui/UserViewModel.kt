package com.example.githubuser_kirani.ui


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser_kirani.data.response.User
import com.example.githubuser_kirani.data.response.UserResponse
import com.example.githubuser_kirani.data.retrofit.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class UserViewModel: ViewModel() {
    val listUsers = MutableLiveData<ArrayList<User>>()
    val errorMessage = MutableLiveData<String>()

    fun setSearchUsers(query: String){
        RetrofitClient.apiInstance
            .getSearchUsers(query)
            .enqueue(object : Callback<UserResponse>{
                override fun onResponse(
                    call: Call<UserResponse>,
                    response: Response<UserResponse>
                ) {
                    if (response.isSuccessful){
                        val users = response.body()?.items
                        if (users != null && users.isNotEmpty()) {
                            listUsers.postValue(users)
                            errorMessage.postValue(null)
                        } else {

                            errorMessage.postValue("Username tidak ditemukan")
                            listUsers.postValue(null)
                        }
                    } else {

                        errorMessage.postValue("Gagal mendapatkan data pengguna")
                        listUsers.postValue(null)
                    }
                }

                override fun onFailure(call: Call<UserResponse>, t: Throwable) {

                    errorMessage.postValue("Terjadi kesalahan saat melakukan pencarian")
                    listUsers.postValue(null)
                }
            })
    }



    fun getSearchUsers(): LiveData<ArrayList<User>>{
        return listUsers
    }
}
