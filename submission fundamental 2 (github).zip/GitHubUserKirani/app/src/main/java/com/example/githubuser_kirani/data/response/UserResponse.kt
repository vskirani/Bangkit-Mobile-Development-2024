package com.example.githubuser_kirani.data.response

class UserResponse(

    val items : ArrayList<User>
)