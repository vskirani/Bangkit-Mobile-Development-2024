package com.example.githubuser_kirani.ui


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.githubuser_kirani.databinding.ActivityDetailUserBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailUserActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_ID = "extra_id"
    }

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var viewModel: DetailUserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userw = intent.getStringExtra(EXTRA_USERNAME)
        val id = intent.getIntExtra(EXTRA_ID, 0)
        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, userw)


        viewModel=ViewModelProvider(this).get(DetailUserViewModel::class.java)
        viewModel.setUserDetail(userw.toString())
        viewModel.getUserDetail().observe(this) {
            if (it != null) {
                binding.apply {
                    duNama.text = it.name
                    duUsername.text = it.login
                    duFollowers.text = "${it.followers} Followers"
                    duFollowing.text = "${it.following} Following"
                    Glide.with(this@DetailUserActivity)
                        .load(it.avatar_url)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .centerCrop()
                        .into(duProfile)
                }
                showLoading(false)
            }
        }

        var _isChecked = false
        CoroutineScope(Dispatchers.IO).launch {
            val count = viewModel.checkUser(id)
            withContext(Dispatchers.Main){
                if (count != null){
                    if(count >0){
                        binding.duToogle.isChecked = true
                        _isChecked = true
                    }else{
                        binding.duToogle.isChecked = false
                        _isChecked = false
                    }
                }
            }
        }

        binding.duToogle.setOnClickListener {
            _isChecked  =! _isChecked
            if (_isChecked){
                viewModel.addToFav(userw.toString(), id)
            }else{
                viewModel.removeFromFav(id)
            }
            binding.duToogle.isChecked = _isChecked
        }


        val pagerAdapter = PagerAdapter(this , supportFragmentManager, bundle)
        binding.apply {
            duView.adapter = pagerAdapter
            duTablayout.setupWithViewPager(duView)

        }
        showLoading(true)

    }

    private fun showLoading(b: Boolean) {
        if(b){
            binding.barProgresDetail.visibility = View.VISIBLE
        }else{
            binding.barProgresDetail.visibility = View.GONE
        }
    }
}