package com.dicoding.asclepius.view

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.asclepius.R
import com.dicoding.asclepius.adapter.ListNewsAdapter
import com.dicoding.asclepius.data.local.entity.ShareEntity
import com.dicoding.asclepius.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    private val resultViewModel by viewModels<ResultViewModel> {
        ViewModelFactory.getInstance(application)
    }
    private val listAdapter by lazy { ListNewsAdapter { url -> moveToNews(url) } }
    private lateinit var binding: ActivityResultBinding

    private var shareEntity: ShareEntity? = ShareEntity()
    private var requestCode: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarResult)

        supportActionBar?.apply {
            title = getString(R.string.result_title)
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
        }

        binding.apply {
            rvBerita.apply {
                adapter = listAdapter
                layoutManager = LinearLayoutManager(this@ResultActivity)
            }
        }

        requestCode = intent.getIntExtra(EXTRA_SHARE, 0)

        if (requestCode == SHARE_REQUEST_CODE) {
            shareEntity = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_LOCAL_DATA, ShareEntity::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_LOCAL_DATA)
            }
        } else {
            shareEntity?.apply {
                imageUri = intent.getStringExtra(EXTRA_IMAGE_URI)
                prediction = intent.getStringExtra(EXTRA_PREDICTION) ?: ""
                confidenceScore = intent.getFloatExtra(EXTRA_CONFIDENCE, 0f)
            }
        }

        shareEntity?.let { share ->
            share.imageUri.let {
                binding.resultImage.setImageURI(Uri.parse(it))
            }
            val predictionAndConfidence = String.format(
                "%s (%.2f%%)", share.prediction, share.confidenceScore
            )
            binding.resultText.text = getString(R.string.result, predictionAndConfidence)
        }

        setNewsData()
    }

    private fun setNewsData() {
        resultViewModel.isLoading.observe(this, ::showLoading)
        resultViewModel.searchNews.observe(this) { newsResponse ->
            if (newsResponse.totalResults > 0) {
                listAdapter.listNews = newsResponse.articles
            } else {
                showTVNoResult(getString(R.string.no_results))
            }
        }

        resultViewModel.isError.observe(this) {
            val message = getString(R.string.error_result_news, it)
            showTVNoResult(message)
        }
    }

    private fun moveToNews(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }

    private fun showLoading(state: Boolean) {
        binding.barprogresResult.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun showTVNoResult(message: String) {
        binding.NoResult.visibility = View.VISIBLE
        binding.NoResult.text = message
    }

    private fun shareResult() {
        shareEntity?.let { share ->
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Hasil Prediksi Kulit anda adalah : ,Prediction: ${share.prediction}, Confidence: ${share.confidenceScore}")
            }
            startActivity(Intent.createChooser(shareIntent, "Share Result"))
        } ?: showToast(getString(R.string.empty_result_warning))
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.result_menu, menu)
        if (requestCode == SHARE_REQUEST_CODE) {
            menu?.findItem(R.id.menu_share)?.isVisible = false
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }

            R.id.menu_share -> {
                shareResult()
            }

        }
        return super.onOptionsItemSelected(item)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_PREDICTION = "extra_prediction"
        const val EXTRA_CONFIDENCE = "extra_confidence"
        const val EXTRA_LOCAL_DATA = "extra_local_data"
        const val EXTRA_SHARE = "extra_share"
        const val SHARE_REQUEST_CODE = 100
    }
}