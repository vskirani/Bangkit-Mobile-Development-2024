package com.example.ngestorykuy.ui.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ngestorykuy.R
import com.example.ngestorykuy.data.Result
import com.example.ngestorykuy.data.adapter.StoryListAdapter
import com.example.ngestorykuy.databinding.ActivityMainBinding
import com.example.ngestorykuy.data.response.Story
import com.example.ngestorykuy.ui.ViewModelFactory
import com.example.ngestorykuy.ui.viewmodel.MainViewModel


class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: StoryListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                setupAction(user.token)
            }
        }
        setupView()
        supportActionBar?.show()

        adapter = StoryListAdapter()
        adapter.notifyDataSetChanged()
        adapter.setOnClickCallback(object : StoryListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Story) {
                Intent(this@MainActivity, DetailStoryActivity::class.java).also {
                    it.putExtra(DetailStoryActivity.NAME, data.name)
                    it.putExtra(DetailStoryActivity.DESC, data.description)
                    it.putExtra(DetailStoryActivity.URL, data.photoUrl)
                    startActivity(it)
                }
            }
        })
        binding.apply {
            rvStory.layoutManager = LinearLayoutManager(this@MainActivity)
            rvStory.setHasFixedSize(true)
            rvStory.adapter = adapter
        }
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.btn_logout -> {
                viewModel.logout()
            }

            R.id.btn_add -> {
                startActivity(Intent(this@MainActivity, AddActivity::class.java))
            }
        }
        return super.onOptionsItemSelected(item)
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    private fun setupAction(token: String) {
        viewModel.story(token).observe(this) { user ->
            if (user != null) {
                when (user) {
                    is Result.Loading -> {
                        binding.mainProgressBar.visibility = View.VISIBLE
                    }

                    is Result.Success -> {
                        binding.mainProgressBar.visibility = View.GONE
                        val adapter = StoryListAdapter()
                        binding.rvStory.layoutManager = LinearLayoutManager(this)
                        adapter.submitList(user.data.listStory)
                        binding.rvStory.adapter = adapter
                    }

                    is Result.Error -> {
                        binding.mainProgressBar.visibility = View.GONE
                        Toast.makeText(this, "Gagal Login", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }


}